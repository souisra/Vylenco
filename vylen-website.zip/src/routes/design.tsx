import { createFileRoute, Link } from "@tanstack/react-router";
import { VylenLayout, Footer } from "@/components/vylen/Layout";

export const Route = createFileRoute("/design")({
  component: DesignPhilosophy,
  head: () => ({
    meta: [
      { title: "How We Design — VYLEN" },
      { name: "description", content: "Discover how VYLEN crafts premium websites engineered to capture attention, hold focus, and convert visitors into loyal customers." },
      { property: "og:title", content: "How We Design — VYLEN" },
      { property: "og:description", content: "Premium, attention-engineered web design for local businesses that refuse to be overlooked." },
      { property: "og:url", content: "https://vylenco.lovable.app/design" },
    ],
    links: [{ rel: "canonical", href: "https://vylenco.lovable.app/design" }],
  }),
});

function DesignPhilosophy() {
  return (
    <VylenLayout>
      <div className="vy-page-hero">
        <p className="vy-label">How We Design</p>
        <h1>Designed to be<br/>impossible to ignore.</h1>
        <p>Every VYLEN website is engineered around one principle — capture attention in the first second, and keep it long enough to convert.</p>
      </div>

      <section className="vy-story-section">
        <div>
          <p className="vy-label">The Method</p>
          <h2>Attention is the new currency —<br/><em style={{ fontStyle: "italic" }}>we design to earn it.</em></h2>
          <p className="body">The modern visitor decides whether to stay or leave in under three seconds. We obsess over those three seconds. Typography, motion, whitespace, contrast, rhythm — every element is tuned to stop the scroll and pull people in.</p>
          <p className="body">We study eye-tracking research, reading patterns, and conversion psychology, then translate that science into design that feels effortless. The result isn't a website that <em>looks</em> premium — it's a website that <em>behaves</em> premium.</p>
          <p className="body">No templates. No stock layouts. No recycled animations. Every pixel is placed with intent, because attention earned is trust earned.</p>
        </div>
        <div className="vy-story-cards">
          {[
            ["Capture", "The first three seconds", "Bold typography, cinematic motion, and considered whitespace pull the visitor in before they even realise it."],
            ["Hold", "Designed to keep eyes moving", "Strategic visual rhythm, micro-interactions, and content hierarchy guide visitors deeper into your story."],
            ["Convert", "From visitor to customer", "Every layout is engineered to lead naturally to the moment they call, book, or buy — without ever feeling pushy."],
          ].map(([label, t, d]) => (
            <div className="vy-story-card" key={label}>
              <p className="vy-label" style={{ marginBottom: 10 }}>{label}</p>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="vy-story-belief">
        <p className="vy-label">Premium by Design</p>
        <blockquote>"A premium website doesn't just show your work — it makes people feel they've found something rare."</blockquote>
        <div style={{ width: 60, height: 1, background: "var(--vy-gold)", margin: "40px auto" }} />
        <p style={{ fontSize: "0.6rem", letterSpacing: "0.25em", textTransform: "uppercase", color: "var(--vy-gold-dim)" }}>— The VYLEN Design Standard</p>
      </section>

      <section className="vy-story-changes">
        <p className="vy-label">What Makes It Premium</p>
        <h2 className="vy-reveal">Built to a standard most agencies skip.</h2>
        <div className="vy-story-changes-grid">
          {[
            ["Cinematic motion that earns attention", "Subtle parallax, considered reveals, and tactile micro-interactions — animation that feels alive without ever feeling busy. Movement with meaning."],
            ["Typography treated as art", "We choose typefaces the way a brand chooses a voice. Hierarchy, spacing, and rhythm are tuned line-by-line to feel editorial, not generic."],
            ["Bespoke layouts, never templates", "Every section is composed from scratch around your brand. No drag-and-drop blocks, no cookie-cutter grids — just design that fits you exactly."],
            ["Performance as a feature", "Premium isn't only how it looks. Pages load in under a second, animations stay buttery on every device, and nothing ever feels sluggish."],
            ["Conversion engineered into the craft", "Beautiful is the baseline. Every CTA, every scroll, every pause is positioned to move visitors toward action without breaking the spell."],
            ["Details only you'll notice — at first", "Custom cursors, ambient sound, considered transitions. The kind of polish that makes visitors say 'this feels different' before they know why."],
          ].map(([t, d]) => (
            <div className="vy-story-change vy-reveal" key={t}>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 60, display: "flex", gap: 20, flexWrap: "wrap" }}>
          <Link to="/booking"><button className="vy-btn-gold">Book a Consultation</button></Link>
          <Link to="/pricing"><button className="vy-btn-outline">View Pricing</button></Link>
        </div>
      </section>

      <Footer />
    </VylenLayout>
  );
}
