import { createFileRoute, Link } from "@tanstack/react-router";
import { VylenLayout, Footer } from "@/components/vylen/Layout";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "VYLEN — Design. Develop. Elevate." },
      { name: "description", content: "Bespoke websites for local businesses that deserve to be seen, remembered, and chosen. Custom design, reliable development, lasting impact." },
      { property: "og:title", content: "VYLEN — Bespoke Websites for Local Businesses" },
      { property: "og:description", content: "Custom design, reliable development, lasting impact. Where your brand finds its voice and the world leans in to listen." },
      { property: "og:url", content: "https://vylenco.lovable.app/" },
    ],
    links: [{ rel: "canonical", href: "https://vylenco.lovable.app/" }],
  }),
});

function Index() {
  return (
    <VylenLayout>
      <section className="vy-hero">
        <h1 className="vy-hero-brand">
          VYLEN
          <span className="sr-only"> — Bespoke Web Design for Local Businesses</span>
        </h1>
        <div className="vy-hero-rule" />
        <div className="vy-hero-tagline">Design &nbsp;·&nbsp; Develop &nbsp;·&nbsp; Elevate</div>
        <p className="vy-hero-motto">"Where your brand finds its voice — and the world leans in to listen."</p>
        <p className="vy-hero-sub">Bespoke websites for local businesses that deserve to be seen, remembered, and chosen.</p>
        <div className="vy-hero-cta">
          <Link to="/booking" className="vy-btn-gold">Book a Consultation</Link>
          <Link to="/design" className="vy-btn-outline">Our Story</Link>
        </div>
      </section>

      <section className="vy-services">
        {[
          ["01", "Refined Design", "We craft visually stunning websites that reflect the character of your brand — no templates, no shortcuts. Every pixel has purpose."],
          ["02", "Reliable Development", "Built to perform flawlessly across all devices. Fast, secure, and built to last — so you can focus on running your business."],
          ["03", "Elevate Your Brand", "Your website is your first impression. We make sure it's an unforgettable one that converts visitors into loyal customers."],
        ].map(([n, t, d]) => (
          <div className="vy-service-card vy-reveal" key={n}>
            <div className="vy-service-num">{n}</div>
            <div className="vy-service-title">{t}</div>
            <p className="vy-service-desc">{d}</p>
          </div>
        ))}
      </section>

      <section className="vy-quote">
        <p className="vy-quote-text vy-reveal">A great website is not built with code alone — it is built with intention, elegance, and an unshakeable belief in your business.</p>
        <p className="vy-quote-author vy-reveal">— The VYLEN Philosophy</p>
      </section>

      <section className="vy-contact">
        <p className="vy-label">Reach Out</p>
        <h2 className="vy-reveal">Let's build something<br/><em style={{ fontFamily: "'Cormorant Garamond',serif", fontStyle: "italic" }}>extraordinary</em> together.</h2>
        <div className="vy-contact-grid">
          <div className="vy-contact-item vy-reveal">
            <h3>Email Us</h3>
            <Link to="/booking">Vylenwebsites@gmail.com</Link>
          </div>
          <div className="vy-contact-item vy-reveal">
            <h3>Start a Project</h3>
            <Link to="/booking">Book a Free Consultation →</Link>
          </div>
        </div>
      </section>

      <Footer />
    </VylenLayout>
  );
}
