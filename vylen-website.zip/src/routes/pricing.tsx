import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { VylenLayout, Footer } from "@/components/vylen/Layout";

export const Route = createFileRoute("/pricing")({
  component: Pricing,
  head: () => ({
    meta: [
      { title: "Pricing — VYLEN" },
      { name: "description", content: "Transparent pricing for bespoke websites. Exceptional value with plans starting at $35 — no hidden fees, just honest, beautiful work." },
      { property: "og:title", content: "VYLEN Pricing — Bespoke Websites from $35" },
      { property: "og:description", content: "Starter, Growth, and Premium plans. Handcrafted websites with transparent pricing and no hidden fees." },
      { property: "og:url", content: "https://vylenco.lovable.app/pricing" },
    ],
    links: [{ rel: "canonical", href: "https://vylenco.lovable.app/pricing" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Service",
          serviceType: "Web Design and Development",
          provider: { "@type": "Organization", name: "VYLEN", url: "https://vylenco.lovable.app" },
          areaServed: "Local businesses",
          hasOfferCatalog: {
            "@type": "OfferCatalog",
            name: "VYLEN Website Plans",
            itemListElement: [
              { "@type": "Offer", name: "Starter", price: "30", priceCurrency: "USD", description: "Single-page website, mobile-responsive, contact form, delivered in 5–7 days." },
              { "@type": "Offer", name: "Growth", price: "40", priceCurrency: "USD", description: "Up to 4 pages, custom design, gallery, SEO foundation, delivered in 7–10 days." },
              { "@type": "Offer", name: "Premium", price: "50", priceCurrency: "USD", description: "Up to 8 pages, full custom animated design, booking system, advanced SEO, delivered in 10–14 days." },
              { "@type": "Offer", name: "Monthly", price: "45", priceCurrency: "USD", description: "Monthly maintenance & optimisation plan. Website kept up-to-date, secure, and performant for $45/mo." },
            ],
          },
        }),
      },
    ],
  }),
});

const plans = [
  { name: "Starter", price: 30, featured: false, btn: "outline" as const, features: [
    "Single-page website", "Mobile-responsive design", "Contact form included",
    "Basic brand colours & fonts", "Delivered in 5–7 days", "1 round of revisions",
  ]},
  { name: "Growth", price: 40, featured: true, btn: "filled" as const, badge: "Most Popular", features: [
    "Up to 4 pages", "Custom interactive design", "Image gallery / portfolio",
    "Social media links", "SEO foundation setup",
    "Delivered in 7–10 days", "3 rounds of revisions",
  ]},
  { name: "Premium", price: 50, featured: false, btn: "outline" as const, features: [
    "Up to 8 pages", "Full custom animated design", "Booking / enquiry system",
    "Live chat integration", "Advanced SEO optimisation", "Performance optimisation",
    "Analytics dashboard setup", "Delivered in 10–14 days", "Unlimited revisions",
  ]},
  { name: "Monthly", price: 45, featured: false, btn: "outline" as const, badge: "Maintained", priceSuffix: "/mo", periodLabel: "Billed monthly", features: [
    "Website maintained & optimised by us",
    "Ongoing performance tuning",
    "Security updates & monitoring",
    "Content & copy updates included",
    "SEO health checks",
    "Priority support",
    "Cancel anytime",
  ]},
];

function Pricing() {
  const [fx, setFx] = useState<{ code: string; symbol: string; rate: number } | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const geo = await fetch("https://ipapi.co/json/").then(r => r.json());
        const code: string = geo?.currency || "USD";
        if (code === "USD") return;
        const fxRes = await fetch(`https://open.er-api.com/v6/latest/USD`).then(r => r.json());
        const rate: number | undefined = fxRes?.rates?.[code];
        if (!rate || cancelled) return;
        const symbol = (0).toLocaleString(undefined, { style: "currency", currency: code })
          .replace(/[\d.,\s]/g, "") || code + " ";
        setFx({ code, symbol, rate });
      } catch {/* fall back to USD */}
    })();
    return () => { cancelled = true; };
  }, []);

  const format = (usd: number) => {
    if (!fx) return { symbol: "$", amount: String(usd) };
    const converted = usd * fx.rate;
    const rounded = fx.code === "INR"
      ? Math.round(converted / 100) * 100
      : converted >= 100 ? Math.round(converted) : Math.round(converted * 100) / 100;
    return { symbol: fx.symbol, amount: rounded.toLocaleString() };
  };

  return (
    <VylenLayout>
      <div className="vy-page-hero">
        <p className="vy-label">Investment</p>
        <h1>Transparent pricing.<br/>Exceptional value.</h1>
        <p>Every plan is handcrafted — no hidden costs, no surprises. Just results.</p>
        {fx && <p style={{ fontSize: "0.75rem", opacity: 0.65, marginTop: 8 }}>Prices shown in {fx.code} (converted from USD at live rates).</p>}
      </div>

      <section className="vy-pricing">
        <p className="vy-label">Our Plans</p>
        <h2 className="vy-reveal">Choose your launchpad.</h2>
        <p className="vy-pricing-subtitle vy-reveal">Whether you're just getting online or ready to go premium, there's a VYLEN plan made for exactly where you are.</p>

        <div className="vy-plans">
          {plans.map(p => (
            <div className={`vy-plan vy-reveal${p.featured ? " featured" : ""}`} key={p.name}>
              {p.badge && <div className="vy-plan-badge">{p.badge}</div>}
              <div className="vy-plan-name">{p.name}</div>
              <div className="vy-plan-price"><span>{format(p.price).symbol}</span>{format(p.price).amount}{"priceSuffix" in p && p.priceSuffix ? <span style={{ fontSize: "1rem", letterSpacing: "0.05em" }}>{p.priceSuffix}</span> : null}</div>
              <div className="vy-plan-period">{"periodLabel" in p && p.periodLabel ? p.periodLabel : "One-time payment"}</div>
              <div className="vy-plan-divider" />
              <ul className="vy-plan-features">
                {p.features.map(f => <li key={f}>{f}</li>)}
              </ul>
              <Link to="/booking">
                <button className={`vy-plan-btn vy-plan-btn-${p.btn}`}>Get Started</button>
              </Link>
            </div>
          ))}
        </div>
      </section>

      <div className="vy-pricing-note vy-reveal">
        All plans include a <strong style={{ color: "var(--vy-gold)" }}>free discovery call</strong> before any payment is taken.<br/>
        Not sure which plan is right for you? <Link to="/booking" style={{ color: "var(--vy-gold)", textDecoration: "none" }}>Let's talk →</Link>
      </div>

      <section className="vy-why" style={{ borderTop: "1px solid rgba(184,151,58,0.1)" }}>
        <p className="vy-label">Worth Every Penny</p>
        <h2 className="vy-reveal">What you always get,<br/>regardless of plan.</h2>
        <div className="vy-why-grid">
          {[
            ["Speed & Performance", "Optimised for fast load times — because every second of delay costs you customers."],
            ["Yours Forever", "Once paid, your website is fully owned by you."],
          ].map(([t, d]) => (
            <div className="vy-why-card vy-reveal" key={t}>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </VylenLayout>
  );
}
