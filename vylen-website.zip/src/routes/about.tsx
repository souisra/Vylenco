import { createFileRoute, Link } from "@tanstack/react-router";
import { VylenLayout, Footer } from "@/components/vylen/Layout";

export const Route = createFileRoute("/about")({
  component: About,
  head: () => ({
    meta: [
      { title: "About — VYLEN" },
      { name: "description", content: "Affordable excellence in web design for local businesses. Custom-built, transparent, and effective — no templates, no shortcuts." },
      { property: "og:title", content: "About VYLEN — Custom Web Design for Local Brands" },
      { property: "og:description", content: "Meet the team behind VYLEN. Affordable, handcrafted websites built to elevate local businesses." },
      { property: "og:url", content: "https://vylenco.lovable.app/about" },
    ],
    links: [{ rel: "canonical", href: "https://vylenco.lovable.app/about" }],
  }),
});

function About() {
  return (
    <VylenLayout>
      <div className="vy-page-hero">
        <p className="vy-label">Our Story</p>
        <h1>Built for the<br/>businesses that<br/>build communities.</h1>
        <p>We believe every local business deserves a digital presence as powerful as their passion.</p>
      </div>

      <section className="vy-about-intro">
        <div>
          <p className="vy-label">Who We Are</p>
          <h2>Affordable Excellence.<br/>No Compromise.</h2>
          <p>VYLEN was founded on a simple but radical idea: exceptional web design should not be a luxury reserved for big budgets. Local businesses — the bakeries, the salons, the boutiques, the repair shops — are the heartbeat of every community.</p>
          <p>We partner with you from concept to launch, creating websites that are not just beautiful but genuinely effective — driving customers, building trust, and growing revenue.</p>
          <p>From a starter page to a fully interactive experience, every VYLEN website is handcrafted with care, delivered on time, and priced so that getting online never feels out of reach.</p>
          <Link to="/pricing"><button className="vy-btn-gold" style={{ marginTop: 20 }}>See Our Plans</button></Link>
        </div>
        <div className="vy-about-visual">
          {[["100%", "Custom-built — no template shortcuts"], ["$35", "Starting price — truly accessible"], ["∞", "Dedication to your success"]].map(([n, l]) => (
            <div className="vy-about-stat vy-reveal" key={l}>
              <div className="vy-about-stat-num">{n}</div>
              <div className="vy-about-stat-label">{l}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="vy-process">
        <p className="vy-label">How It Works</p>
        <h2>Simple. Transparent. Effective.</h2>
        <div className="vy-process-steps">
          {[
            ["01", "Discovery Call", "We sit down (virtually or in person) and learn everything about your business, your customers, and your goals."],
            ["02", "Design & Review", "We present bespoke design concepts tailored to your brand — refining until every detail feels right."],
            ["03", "Build & Test", "Your website is developed with precision, tested across devices, and optimised for speed and performance."],
            ["04", "Launch & Support", "We go live together — and we don't disappear afterwards. Ongoing support is always available."],
          ].map(([n, t, d]) => (
            <div className="vy-process-step vy-reveal" key={n}>
              <div className="vy-process-step-num">{n}</div>
              <div className="vy-process-step-title">{t}</div>
              <p className="vy-process-step-desc">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="vy-why">
        <p className="vy-label">Why VYLEN</p>
        <h2 className="vy-reveal">Not just a website.<br/>A competitive advantage.</h2>
        <div className="vy-why-grid">
          {[
            ["Locally Focused", "We understand the unique challenges local businesses face. We design with your specific community and customer base in mind."],
            ["Radically Affordable", "No hidden fees. No bloated retainers. Our transparent pricing means you always know what you're getting — and what you're paying."],
            ["Fast Turnaround", "We know time is money. Our efficient process gets your business online quickly, without cutting corners on quality."],
            ["Genuinely Interactive", "From booking forms to galleries to animated sections — we build websites your customers actually enjoy using."],
            ["Mobile-First Always", "Over 70% of your customers will find you on a phone. Every VYLEN site looks and works flawlessly on every device."],
            ["Ongoing Partnership", "We build lasting relationships. As your business grows, your website grows with it. We're with you for the long haul."],
          ].map(([t, d]) => (
            <div className="vy-why-card vy-reveal" key={t}>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="vy-contact">
        <p className="vy-label">Ready?</p>
        <h2 className="vy-reveal">Your business deserves<br/>to shine online.</h2>
        <div className="vy-contact-grid">
          <div className="vy-contact-item vy-reveal">
            <h3>Start Today</h3>
            <Link to="/booking">Book a Free Consultation →</Link>
          </div>
          <div className="vy-contact-item vy-reveal">
            <h3>See Pricing</h3>
            <Link to="/pricing">View Our Plans →</Link>
          </div>
        </div>
      </section>

      <Footer />
    </VylenLayout>
  );
}
