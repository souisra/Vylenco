import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { VylenLayout } from "@/components/vylen/Layout";

export const Route = createFileRoute("/booking")({
  component: Booking,
  head: () => ({
    meta: [
      { title: "Book a Consultation — VYLEN" },
      { name: "description", content: "Book your free discovery call with VYLEN. No pressure, no commitment — just a conversation about your vision and how we can elevate your brand." },
      { property: "og:title", content: "Book a Free Consultation with VYLEN" },
      { property: "og:description", content: "Tell us about your business and we'll be in touch within 24 hours to schedule your free discovery call." },
      { property: "og:url", content: "https://vylenco.lovable.app/booking" },
    ],
    links: [{ rel: "canonical", href: "https://vylenco.lovable.app/booking" }],
  }),
});

function Booking() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", email: "", message: "" });

  const submit = () => {
    if (!form.name || !form.phone || !form.email) {
      alert("Please fill in your name, phone number, and email.");
      return;
    }
    const subject = encodeURIComponent("New Booking Request from " + form.name);
    const body = encodeURIComponent(
      `Name: ${form.name}\nPhone: ${form.phone}\nEmail: ${form.email}\n\nMessage:\n${form.message}`
    );
    window.location.href = `mailto:Vylenwebsites@gmail.com?subject=${subject}&body=${body}`;
    setSent(true);
  };

  const upd = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm({ ...form, [k]: e.target.value });

  return (
    <VylenLayout>
      <div className="vy-booking">
        <div className="vy-booking-left">
          <p className="vy-label">Let's Talk</p>
          <h1>Book a Consultation</h1>
          <h2>Your next chapter starts with a single conversation.</h2>
          <p>Fill in the form and we'll be in touch within 24 hours to schedule your free discovery call. No pressure, no commitment — just a conversation about your vision.</p>
          <div style={{ marginTop: 50, borderTop: "1px solid rgba(184,151,58,0.2)", paddingTop: 40 }}>
            <p style={{ fontSize: "0.6rem", letterSpacing: "0.2em", textTransform: "uppercase", color: "var(--vy-gold)", marginBottom: 10 }}>Email</p>
            <p style={{ color: "#aaa", fontFamily: "'Cormorant Garamond',serif", fontSize: "1.1rem" }}>Vylenwebsites@gmail.com</p>
          </div>
        </div>

        <div className="vy-booking-right">
          {!sent ? (
            <div>
              <p style={{ fontSize: "0.6rem", letterSpacing: "0.25em", textTransform: "uppercase", color: "var(--vy-gold)", marginBottom: 32 }}>Booking Request</p>
              <div className="vy-form-group">
                <label htmlFor="booking-name">Full Name</label>
                <input id="booking-name" type="text" value={form.name} onChange={upd("name")} placeholder="Your name" />
              </div>
              <div className="vy-form-group">
                <label htmlFor="booking-phone">Phone Number</label>
                <input id="booking-phone" type="tel" value={form.phone} onChange={upd("phone")} placeholder="+91 00000 00000" />
              </div>
              <div className="vy-form-group">
                <label htmlFor="booking-email">Email Address</label>
                <input id="booking-email" type="email" value={form.email} onChange={upd("email")} placeholder="you@example.com" />
              </div>
              <div className="vy-form-group">
                <label htmlFor="booking-message">Tell us about your business</label>
                <textarea id="booking-message" value={form.message} onChange={upd("message")} placeholder="What does your business do? What are you hoping to achieve with a new website?" />
              </div>
              <button className="vy-form-submit" onClick={submit}>Send Booking Request</button>
              <div style={{ marginTop: 28, padding: "18px 20px", border: "1px solid rgba(184,151,58,0.25)", borderRadius: 4, background: "rgba(184,151,58,0.04)" }}>
                <p style={{ fontSize: "0.6rem", letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--vy-gold)", marginBottom: 10 }}>Privacy Policy</p>
                <p style={{ color: "#bbb", fontFamily: "'Cormorant Garamond',serif", fontSize: "0.95rem", lineHeight: 1.6, margin: 0 }}>
                  We collect your <strong>name</strong> so we can address you personally, your <strong>email</strong> and <strong>phone number</strong> so we can reach out to schedule your discovery call, and your <strong>business description</strong> so we can prepare meaningfully for our conversation. Your information is used solely by the VYLEN team to respond to your request — it is never sold, shared with third parties, or used for marketing. All details are transmitted securely and stored confidentially. You may request deletion of your data at any time by emailing <strong>Vylenwebsites@gmail.com</strong>.
                </p>
              </div>
            </div>
          ) : (
            <div className="vy-form-success">
              <div className="vy-check">✓</div>
              <h3>Request Received</h3>
              <p>Thank you! We've sent your details to <strong>Vylenwebsites@gmail.com</strong> and will be in touch within 24 hours.</p>
              <Link to="/"><button className="vy-btn-gold" style={{ marginTop: 30 }}>Back to Home</button></Link>
            </div>
          )}
        </div>
      </div>
    </VylenLayout>
  );
}
