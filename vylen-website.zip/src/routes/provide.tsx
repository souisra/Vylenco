import { createFileRoute } from "@tanstack/react-router";
import { VylenLayout } from "@/components/vylen/Layout";

export const Route = createFileRoute("/provide")({
  component: Provide,
  head: () => ({
    meta: [
      { title: "What We Provide — VYLEN" },
      { name: "description", content: "Three schools of design, one vision of excellence." },
    ],
  }),
});

function Provide() {
  return (
    <VylenLayout>
      <iframe
        src="/provide.html"
        title="What We Provide"
        style={{ display: "block", width: "100%", height: "calc(100vh - 80px)", border: "none", marginTop: "80px" }}
      />
    </VylenLayout>
  );
}
