import { createFileRoute, Link } from "@tanstack/react-router";
import { VylenLayout, Footer } from "@/components/vylen/Layout";

export const Route = createFileRoute("/story")({
  component: Story,
  head: () => ({
    meta: [
      { title: "Our Story — VYLEN" },
      { name: "description", content: "We don't just build websites — we build reputations. Discover the VYLEN philosophy and how we transform local businesses online." },
      { property: "og:title", content: "Our Story — The VYLEN Philosophy" },
      { property: "og:description", content: "How VYLEN transforms local businesses with websites built on intention, elegance, and craft." },
      { property: "og:url", content: "https://vylenco.lovable.app/story" },
    ],
    links: [{ rel: "canonical", href: "https://vylenco.lovable.app/story" }],
  }),
});

function Story() {
  return (
    <VylenLayout>
      <div className="vy-page-hero">
        <p className="vy-label">Our Story</p>
        <h1>We don't just build<br/>websites. We build<br/>reputations.</h1>
        <p>Every great business deserves a digital presence that commands attention and earns trust.</p>
      </div>

      <section className="vy-story-section">
        <div>
          <p className="vy-label">The VYLEN Way</p>
          <h2>Design that doesn't follow trends —<br/><em style={{ fontStyle: "italic" }}>it sets them.</em></h2>
          <p className="body">At VYLEN, we believe the most powerful thing a business can own is a strong first impression. In a world where attention lasts seconds, your website is the handshake, the storefront, and the pitch — all at once.</p>
          <p className="body">We don't start with templates. We start with questions. Who are your customers? What feeling should they leave with? What makes your business impossible to ignore? Only then do we open a design file.</p>
          <p className="body">The result is a website that doesn't just look good — it <em>thinks</em> for your business, guiding every visitor naturally toward calling you, visiting you, or trusting you.</p>
        </div>
        <div className="vy-story-cards">
          {[
            ["Innovation", "Designs that attract, hold, and convert", "We study what makes people stop scrolling, look twice, and ultimately reach out. Every visual decision is intentional."],
            ["Transformation", "Change how the world sees your business", "A VYLEN website doesn't just represent your brand — it elevates it. Customers begin to associate you with professionalism, quality, and trust."],
            ["Perception", "From local shop to local legend", "We've seen businesses double their enquiries simply by finally looking the part online. Your website changes what people think — and feel — about you."],
          ].map(([label, t, d]) => (
            <div className="vy-story-card" key={label}>
              <p className="vy-label" style={{ marginBottom: 10 }}>{label}</p>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="vy-story-belief">
        <p className="vy-label">Our Belief</p>
        <blockquote>"The moment your website reflects the true quality of your work, everything changes. Customers arrive already believing in you."</blockquote>
        <div style={{ width: 60, height: 1, background: "var(--vy-gold)", margin: "40px auto" }} />
        <p style={{ fontSize: "0.6rem", letterSpacing: "0.25em", textTransform: "uppercase", color: "var(--vy-gold-dim)" }}>— The VYLEN Founding Principle</p>
      </section>

      <section className="vy-story-changes">
        <p className="vy-label">What Changes</p>
        <h2 className="vy-reveal">How a VYLEN website transforms your business.</h2>
        <div className="vy-story-changes-grid">
          {[
            ["Customers trust you before they meet you", "A polished, professional website signals credibility. People decide whether to call you within 3 seconds of landing on your page. We make those 3 seconds count."],
            ["You stand apart from every competitor", "Most local businesses have outdated, generic websites — or none at all. A VYLEN site immediately positions you as the premium, trustworthy choice in your area."],
            ["Your story finally gets told properly", "Every business has a reason to exist, a passion behind it. We find that story and build it into every section — so customers don't just buy from you, they believe in you."],
            ["Growth becomes visible and measurable", "More enquiries, more bookings, more walk-ins. A website that works for you around the clock — even when you're closed — is your most valuable employee."],
          ].map(([t, d]) => (
            <div className="vy-story-change vy-reveal" key={t}>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 60, display: "flex", gap: 20 }}>
          <Link to="/booking"><button className="vy-btn-gold">Start Your Transformation</button></Link>
          <Link to="/pricing"><button className="vy-btn-outline">View Pricing</button></Link>
        </div>
      </section>

      <Footer />
    </VylenLayout>
  );
}
