import { useEffect, useRef } from "react";

/**
 * Plays a calming ambient track on page load.
 * Browsers block audible autoplay before user interaction, so we also
 * start on the first user gesture as a fallback.
 */
export function AmbientAudio() {
  const ref = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const a = ref.current;
    if (!a) return;
    a.volume = 0.25;

    const tryPlay = () => {
      a.play().catch(() => {});
    };

    tryPlay();

    const events: (keyof DocumentEventMap)[] = [
      "click", "keydown", "touchstart", "pointerdown", "scroll",
    ];
    const handler = () => {
      tryPlay();
      events.forEach((ev) => document.removeEventListener(ev, handler));
    };
    events.forEach((ev) =>
      document.addEventListener(ev, handler, { once: true, passive: true })
    );

    return () => {
      events.forEach((ev) => document.removeEventListener(ev, handler));
      a.pause();
    };
  }, []);

  return (
    <audio
      ref={ref}
      src="/audio/ambient.mp3"
      loop
      preload="auto"
      aria-hidden="true"
    />
  );
}
