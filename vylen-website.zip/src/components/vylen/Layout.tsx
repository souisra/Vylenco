import { useEffect, useRef, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { AmbientAudio } from "./AmbientAudio";

function Cursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const dot = dotRef.current;
    const ring = ringRef.current;
    if (!dot || !ring) return;

    // Skip entirely on touch / coarse devices — no cursor exists to track.
    const coarse = window.matchMedia("(hover: none), (pointer: coarse)");
    let disabled = coarse.matches;
    const applyDisabled = () => {
      dot.style.display = disabled ? "none" : "";
      ring.style.display = disabled ? "none" : "";
    };
    applyDisabled();
    const onCoarseChange = (e: MediaQueryListEvent) => {
      disabled = e.matches;
      applyDisabled();
    };
    coarse.addEventListener?.("change", onCoarseChange);
    if (disabled) {
      return () => coarse.removeEventListener?.("change", onCoarseChange);
    }

    // Start off-screen so nothing flashes at (0,0) before first pointer move.
    let mx = -9999, my = -9999;
    let rx = mx, ry = my;
    let hasMoved = false;
    let visible = false;
    let raf = 0;
    let running = true;
    const HOVER_SEL =
      "a, button, input, textarea, select, [role='button'], label, summary, [data-cursor='hover']";

    const show = () => {
      if (visible || !hasMoved) return;
      visible = true;
      dot.style.opacity = "1";
      ring.style.opacity = "0.6";
    };
    const hide = () => {
      if (!visible) return;
      visible = false;
      dot.style.opacity = "0";
      ring.style.opacity = "0";
    };

    const setHover = (t: EventTarget | null) => {
      const el = t as Element | null;
      const isHover = !!(el && el.closest && el.closest(HOVER_SEL));
      dot.classList.toggle("hover", isHover);
      ring.classList.toggle("hover", isHover);
    };

    const onMove = (e: PointerEvent) => {
      // Ignore non-mouse pointers (pen/touch) — they don't have a hover cursor.
      if (e.pointerType && e.pointerType !== "mouse") return;
      mx = e.clientX;
      my = e.clientY;
      if (!hasMoved) {
        hasMoved = true;
        rx = mx;
        ry = my;
      }
      show();
      setHover(e.target);
    };

    // Hide only when the pointer truly leaves the window
    // (relatedTarget null means it exited the viewport, not just crossed elements).
    const onOut = (e: PointerEvent) => {
      if (!e.relatedTarget) hide();
    };
    const onOver = (e: PointerEvent) => {
      if (e.pointerType && e.pointerType !== "mouse") return;
      show();
      setHover(e.target);
    };
    const onBlur = () => hide();
    const onVisibility = () => { if (document.hidden) hide(); };
    const onPointerDown = (e: PointerEvent) => setHover(e.target);

    const loop = () => {
      if (!running) return;
      // Snap dot directly to pointer for zero-lag accuracy.
      dot.style.transform = `translate3d(${mx}px, ${my}px, 0) translate(-50%, -50%)`;
      // Ease the ring toward the dot.
      rx += (mx - rx) * 0.2;
      ry += (my - ry) * 0.2;
      ring.style.transform = `translate3d(${rx}px, ${ry}px, 0) translate(-50%, -50%)`;
      raf = requestAnimationFrame(loop);
    };

    // Reset any stale inline left/top from CSS or previous mounts.
    dot.style.left = "0"; dot.style.top = "0";
    ring.style.left = "0"; ring.style.top = "0";
    dot.style.opacity = "0";
    ring.style.opacity = "0";

    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerover", onOver, { passive: true });
    window.addEventListener("pointerout", onOut, { passive: true });
    window.addEventListener("pointerdown", onPointerDown, { passive: true });
    window.addEventListener("blur", onBlur);
    document.addEventListener("visibilitychange", onVisibility);
    raf = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerover", onOver);
      window.removeEventListener("pointerout", onOut);
      window.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("blur", onBlur);
      document.removeEventListener("visibilitychange", onVisibility);
      coarse.removeEventListener?.("change", onCoarseChange);
    };
  }, []);

  return (
    <>
      <div ref={dotRef} className="vy-cursor" />
      <div ref={ringRef} className="vy-cursor-ring" />
    </>
  );
}

function Nav() {
  const navRef = useRef<HTMLElement>(null);
  useEffect(() => {
    const onScroll = () => {
      if (navRef.current) navRef.current.classList.toggle("scrolled", window.scrollY > 50);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <nav ref={navRef} className="vy-nav">
      <Link to="/" className="vy-nav-logo">VYLEN</Link>
      <div className="vy-nav-links">
        <Link to="/">Home</Link>
        <Link to="/about">About Us</Link>
        <Link to="/provide">What We Provide</Link>
        <Link to="/pricing">Pricing</Link>
        <Link to="/booking" className="vy-nav-cta">Get Started</Link>
      </div>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="vy-footer">
      <span className="vy-f-brand">VYLEN</span>
      <span>Design. Develop. Elevate.</span>
      <span>© 2026 Vylen. All rights reserved.</span>
    </footer>
  );
}

export function useReveal() {
  const pathname = useRouterState({ select: s => s.location.pathname });
  useEffect(() => {
    window.scrollTo({ top: 0 });
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.12 });
    document.querySelectorAll(".vy-reveal").forEach(el => { el.classList.remove("visible"); obs.observe(el); });
    return () => obs.disconnect();
  }, [pathname]);
}

export function VylenLayout({ children }: { children: ReactNode }) {
  useReveal();
  return (
    <div className="vy-root">
      <Cursor />
      <Nav />
      <main>{children}</main>
      <AmbientAudio />
    </div>
  );
}
